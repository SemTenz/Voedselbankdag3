

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Leveranciers</h1>
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Naam</th>
                    <th>Contactpersoon</th>
                    <th>Leverancier Nummer</th>
                    <th>Leverancier Type</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $leveranciers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leverancier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($leverancier->id); ?></td>
                        <td><?php echo e($leverancier->naam); ?></td>
                        <td><?php echo e($leverancier->contactpersoon); ?></td>
                        <td><?php echo e($leverancier->leverancier_nummer); ?></td>
                        <td><?php echo e($leverancier->leverancier_type); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bram\OneDrive - MBO Utrecht\Bureaublad\Voedselbankdag3\Voedselbank\resources\views/leverancier/index.blade.php ENDPATH**/ ?>