<!-- resources/views/home/index.blade.php -->


<?php $__env->startSection('content'); ?>
    <div class="container mx-auto py-12">
        <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg p-6 text-gray-900 dark:text-gray-100">
            <h1 class="text-2xl font-semibold mb-4">Welkom op de homepagina</h1>
            <p class="mb-4">Je bent ingelogd!</p>
            <a href="<?php echo e(route('leveranciers.index')); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                Bekijk Leveranciers
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bram\OneDrive - MBO Utrecht\Bureaublad\Voedselbankdag3\Voedselbank\resources\views/home/index.blade.php ENDPATH**/ ?>